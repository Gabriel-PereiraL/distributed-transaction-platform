# Progresso — terceiro projeto Java

Atualização: 11/10/2026, America/Sao_Paulo.
**Estado: F0/F1 concluídas e verificadas. Aprovação de 11/10/2026: “pode dar inicio a primeira fase”.** F2 NÃO autorizada; proibição de deploy/cloud permanece.

## Objetivo e limites

Construir plataforma Java 21/Spring sintética por fases, preservando os Fulfillment Hubs. Pesquisa/plano entregues; autorização atual cobre apenas fundação. Nunca deploy AWS/recursos pagos.

## Concluído

- Pedido anexado lido e copiado para work/objetivo-terceiro-projeto.txt.
- Skills java-development e token-saver revisadas e instaladas com skill-installer em ~/.codex/skills. Revisões em CODEX.md. Disponíveis ao catálogo no próximo turno; instruções já lidas/aplicadas nesta sessão.
- AGENTS.md raiz aponta para este progresso e CODEX.md.
- Cinco URLs LinkedIn fornecidas lidas; adicionais CashMe, Bradesco e Sicredi lidas. Oito vagas consolidadas em PESQUISA_E_FONTES.md; Docket original inacessível e excluída.
- Auditoria anterior disponível em outputs/auditoria-fulfillment-hub-2026-10-11.md. Repositórios em work/fulfillment-hub e work/fulfillment-hub-java são referências, não alvos de alteração.
- PROPOSTA_ARQUITETURAL.md concluída: produto, I1–I12, componentes/contratos, fases F0–F8, esforço, testes, AWS-ready/custos, riscos e critérios de conclusão.
- REQUIREMENTS_MATRIX.md atualizada: 20 linhas com implementação/testes F1 ou evidência parcial; 32 pendentes. Sem cobertura de fases futuras por dependência declarada.
- Links locais dos cinco Markdown conferidos: nenhum link local quebrado reportado. Custos ilustrativos conferidos: Fargate ~US$72,08 + MSK ~US$476,76 = subtotal ~US$548,84/mês, sem demais serviços.
- Código novo somente em synthetic-ledger/. Hubs mantêm git status limpo; nenhuma cloud/infra paga criada.

## Decisões provisórias

Plano aceito para início F0/F1. PostgreSQL é autoridade; F1 só admite/reserva, sem posting. Quatro módulos implementados: domain/application/adapters/api; contratos v1 e ADR. Java 21/Boot 4.1.1/Maven 3.9.16 resolvidos e compilados. JWT RSA/JWKS/scopes + ownership/tenant; Keycloak posterior. Kafka/Mongo/Redis/worker não implementados. Três executáveis permanecem desenho futuro; API atual é único host. Redis nunca saldo; replay futuro só leitura; sem exactly-once.

## Próximas ações exatas

1. Entregar README/projeto/pacote F1 e resumo de publicação solicitado (POST_LINKEDIN.md).
2. Aguardar revisão/autorização de F2; só então adicionar posting/Kafka/recovery por migrations, preservando o contrato de admissão.
3. Ao retomar, ler synthetic-ledger/README.md e docs/VALIDATION_F1.md; conferir estado local. Não repetir pesquisa nem baixar runtimes se os existentes estiverem íntegros.

## Evidência F1

Docker iniciado e disponível (29.4.2). JDK Temurin 21 e Maven 3.9.16 baixados para work/toolchains com checksums verificados; não instalados globalmente.
Maven Wrapper oficial e checksum da distribuição fixados. Comando final: ./mvnw.cmd -B -ntp -Pintegration clean verify — BUILD SUCCESS, 39 testes, zero falhas/erros/skips (13 domain, 4 application, 2 architecture, 20 IT HTTP/PostgreSQL/JWKS). Testa 20 same-key e 20 last-funds, rollback de evento, recuperação sem resposta, SQL guards, auth negativo, seed idempotente e health.
OpenAPI/JSON Schema/evento SQL real validados; resumo em synthetic-ledger/docs/evidence/f1-validation.json. Script scripts/validate-contracts.py também executado. Comando migrate sem gate foi executado e recusou (exit1) antes de acessar DB. Log final em work/f1-tests-final.log; runtimes em work/toolchains.
Limites: sem Keycloak/flows OIDC/ACL, Kafka/posting, Mongo/Redis, collector/trace distribuído, benchmarks ou CI/cloud executados. Holds/outbox ficam pendentes em F1; não há liquidação.
Pacote entregue: outputs/dtp-fundacao-f1.zip, 57 arquivos de fontes/documentos, sem target/logs/toolchains/segredos. Integridade ZIP conferida pelo script work/package-f1.py. Resumo para publicação em POST_LINKEDIN.md. Próxima fase permanece não autorizada.

## Comandos e limitações

Skill installers já concluídos. Docker iniciou nesta sessão; containers de teste descartáveis, sem reuse/banco externo. Não usar resultados dos Hubs como evidência DTP. Validadores Python isolados em work/validation-packages. Nenhuma skill promete recuperação de ações não salvas.

## Retomada

Ler este arquivo e CODEX.md antes de ampliar contexto. Ler proposta/matriz por seção. Atualizar checkpoint após gate/decisão e antes de encerrar/compactar. Arquivo salvo permite retomar; não garante recuperar ação interrompida antes de salvar.

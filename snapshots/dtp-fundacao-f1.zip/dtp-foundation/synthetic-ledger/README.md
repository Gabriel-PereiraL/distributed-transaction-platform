# DTP — Synthetic Ledger & Transaction Processing

Java 21 / Spring Boot 4.1.1 / PostgreSQL. Phase 1 foundation: **admission and reservation only**, with no money movement. Kafka posting, MongoDB read models, Redis quotas, Keycloak and observability exporters are later phases.

## What is implemented

- Three protected operations: admit a transfer, read an initiated transfer, read an owned customer account.
- Atomic admission: scoped idempotency identity + hold + reservation + canonical event + pending outbox.
- Ownership and tenant isolation in addition to OAuth scopes; RS256 signature/issuer/audience/time/claim validation through JWKS.
- Domain/application without Spring/JPA dependencies. SQL/JPA adapters compose short local transactions, without network effects.
- PostgreSQL deferred guards for balanced synthetic funding, materialized balance/reservations, matching transfer hold/event, and immutable records.
- Real HTTP/PostgreSQL tests including simultaneous requests, last funds, lost response recovery, failed event persistence and negative authorization.

`ACCEPTED` is not `POSTED`. Phase 1 has no posting worker, reversal, release, automatic expiry, reconciliation or rate limiter. All admitted holds remain pending until phase 2. Do not use it as a payment service.

## Build and tests

Prerequisites: JDK 21 (`JAVA_HOME`), internet for first dependency download; Docker Desktop/Engine for integration. Maven Wrapper downloads Maven 3.9.16 with its checksum. No global Maven installation is required.

```powershell
./mvnw.cmd -B -ntp clean verify
./mvnw.cmd -B -ntp -Pintegration clean verify
# alternatively:
./scripts/verify.ps1 -Integration
```

Linux/macOS: `./mvnw -B -ntp -Pintegration clean verify`.

Default verify runs domain/application/architecture tests. The integration profile additionally starts its own PostgreSQL 17.6 container pinned by digest, applies Flyway, starts the HTTP API and an ephemeral test RSA issuer/JWKS server. Ports and tenants are isolated; no container reuse or external database URL. Tests never point to the Fulfillment Hubs. Mockito only injects a repository failure in one rollback scenario; the remaining persistence is real.

Reports: each module's `target/surefire-reports`, `ledger-api/target/failsafe-reports`, and `target/site/jacoco`. Contracts: `contracts/openapi.yaml` and `contracts/transfer-accepted.v1.schema.json`. Test-generated synthetic event sample: `ledger-api/target/artifacts/accepted-event.json`.

Optional contract validation after integration (Python 3 in an isolated virtual environment): install `scripts/requirements-contracts.txt`, then run `python scripts/validate-contracts.py`. This validation has no service or cloud access.

## Running the API with a dedicated local database

Use a new database reserved for DTP; configure credentials outside the repo. Infrastructure orchestration and a bundled Keycloak realm are intentionally deferred. The HTTP acceptance tests above already reproduce the complete F1 path automatically, without configuring an identity provider manually.

Required runtime environment:

| Variable | Meaning |
|---|---|
| DTP_DATABASE_URL | JDBC URL of the DTP PostgreSQL database |
| DTP_DATABASE_USER / DTP_DATABASE_PASSWORD | Database credentials |
| DTP_ISSUER | Trusted OIDC issuer |
| DTP_JWK_SET_URI | Trusted JWKS endpoint; RS256 keys |
| DTP_AUDIENCE | Expected audience, default `dtp-ledger` |
| DTP_BIND_ADDRESS / DTP_PORT | Defaults loopback / 8085 |

First apply migrations as an explicit one-off command. It does not require an identity provider:

```powershell
$env:DTP_ALLOW_MIGRATION = 'true'
java -jar ledger-api/target/ledger-api-0.1.0-SNAPSHOT.jar migrate
Remove-Item Env:DTP_ALLOW_MIGRATION
```

Apply `docs/local-seed.sql` with `psql -v ON_ERROR_STOP=1 --file docs/local-seed.sql` against that dedicated database; all values are synthetic. The seed is idempotent. Runtime defaults do not apply Flyway on startup (`DTP_MIGRATE_ON_START=false`). Then:

```powershell
java -jar ledger-api/target/ledger-api-0.1.0-SNAPSHOT.jar
```

JWT claims: `sub=alice`, `tenant_id=10000000-0000-0000-0000-000000000001`, authorized party `azp` identifying the OAuth client, `aud=dtp-ledger`, configured `iss`, expiration and scopes `transfer:write transfer:read`. No development signing secret or test private key is committed. This phase accepts correctly minted RSA tokens, but does not provision Keycloak or use password grants.

Admission example (send with bearer and `Idempotency-Key`, through any HTTP client):

```json
{
  "sourceAccountId": "20000000-0000-0000-0000-000000000001",
  "destinationAccountId": "20000000-0000-0000-0000-000000000002",
  "amountCents": 1000,
  "currency": "BRL"
}
```

Result: 202 + Location + stable admission. Same admitted key/payload replays it; a changed payload is 422. Keys are scoped by tenant, subject, OAuth client and operation. A rolled-back rejection leaves no key reservation, so a corrected request can retry. Unknown fields and fractional cents are rejected. Account and transfer queries require read scope and object authorization, returning uniform 404 outside it.

Health: `/actuator/health/liveness` and `/actuator/health/readiness` (including SQL); other Actuator paths are denied. API request bodies are limited to 16 KiB; responses are no-store with bounded correlation IDs. Trace context hooks capture actual server span when enabled; Kafka propagation/export/dashboards are not yet validated. Runtime database role hardening and full OIDC/ACL/threat review remain later work.

See [ADR-001](docs/ADR-001-foundation-boundaries.md) and [validation evidence](docs/VALIDATION_F1.md). No cloud deployment, Terraform apply, resources or changes to the Fulfillment Hubs are part of this project.

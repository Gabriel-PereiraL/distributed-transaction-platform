"""Validate specifications and the event produced by -Pintegration verify.

Install requirements-contracts.txt in an isolated venv. No service/cloud access.
"""
from pathlib import Path
import json
import jsonschema
import yaml
from openapi_spec_validator import validate_spec

root = Path(__file__).resolve().parent.parent
validate_spec(yaml.safe_load((root / "contracts/openapi.yaml").read_text(encoding="utf-8")))
schema = json.loads((root / "contracts/transfer-accepted.v1.schema.json").read_text(encoding="utf-8"))
jsonschema.Draft202012Validator.check_schema(schema)
sample_path = root / "ledger-api/target/artifacts/accepted-event.json"
if not sample_path.exists():
    raise SystemExit("Run ./mvnw -Pintegration verify first: persisted event sample missing.")
sample = json.loads(sample_path.read_text(encoding="utf-8"))
jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker()).validate(sample)
assert sample["tenantId"] == sample["payload"]["tenantId"]
assert sample["aggregateId"] == sample["payload"]["id"]
assert sample["occurredAt"] == sample["payload"]["acceptedAt"]
print("OpenAPI, event schema and actual persisted event validated.")

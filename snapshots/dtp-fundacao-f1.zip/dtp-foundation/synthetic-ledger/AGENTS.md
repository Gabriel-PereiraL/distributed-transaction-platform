# Synthetic Ledger

Ler ../PROGRESSO.md e ../CODEX.md. F0/F1 autorizadas em 11/10/2026; fases posteriores exigem autorização.
Usar java-development/token-saver. Java 21; Maven Wrapper; Spring Boot BOM.
Sem deploy/cloud/AWS/apply; sem alterações nos Fulfillment Hubs.
Domínio/aplicação sem Spring/JPA. PostgreSQL é autoridade; testes usam Testcontainers sem reuse ou banco externo.
Não acrescentar Kafka/Redis/Mongo/worker nesta fase. ACCEPTED não significa dinheiro transferido; nenhum dinheiro real.
Antes de entregar: ./mvnw verify e ./mvnw -Pintegration verify com Docker; registrar execuções reais e atualizar ../PROGRESSO.md.

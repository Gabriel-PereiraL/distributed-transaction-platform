package dev.dtp.activity;

import java.util.UUID;
import org.springframework.security.oauth2.jwt.Jwt;

record ActivityIdentity(UUID tenantId, String subject, String clientId) {
    static ActivityIdentity from(Jwt jwt) {
        var tenant = jwt.getClaimAsString("tenant_id"); var subject = jwt.getSubject(); var client = jwt.getClaimAsString("azp");
        if (tenant == null || subject == null || subject.isBlank() || subject.length() > 128 || client == null || client.isBlank() || client.length() > 128) {
            throw new IllegalArgumentException("Required identity claims missing.");
        }
        return new ActivityIdentity(UUID.fromString(tenant), subject, client);
    }
}

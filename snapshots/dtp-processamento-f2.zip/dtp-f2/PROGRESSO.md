# Progresso — terceiro projeto Java
Atualização: 11/10/2026, America/Sao_Paulo. **F0/F1 e F2 locais concluídas e verificadas. F3+ não autorizadas.**

## Objetivo, autorização e limites
Plataforma Java 21/Spring sintética, pedido completo em work/objetivo-terceiro-projeto.txt. F0/F1 aprovadas com “pode dar inicio a primeira fase”; F2 com “Sim, autorizar F2 local”: posting, Kafka/outbox e recuperação. Pedido atual é continuar até aproximadamente 5% restantes da janela de 5h; consultar snapshots e salvar checkpoint. Janela renovou durante trabalho; última consulta 84% restantes. Continuar depende do gate F3+ reforçado pelo usuário; “de continuidade” manteve o trabalho F2. Nunca deploy/AWS/apply/recursos cloud/pagos, dinheiro real ou alterações nos Fulfillment Hubs.

## Entregue
Plano/proposta, pesquisa de oito vagas e matriz em outputs/dtp. Auditoria anterior em outputs/auditoria-fulfillment-hub-2026-10-11.md; clones work/fulfillment-hub e work/fulfillment-hub-java são referências, ambos git status limpo. Skills token-saver/java-development instaladas e lidas; versões/paths em CODEX.md. AGENTS raiz/projeto refletem autorização F2.
Projeto synthetic-ledger: domain/application/adapters/api/worker. PostgreSQL autoridade; Kafka transporte. Admission/key/hold/event/outbox atômicos; JWT tenant/ownership/scopes. F2 implementa journal double-entry, POSTED/REJECTED, release/dedup/event/outbox; GET atual, POST replay original. Regra synthetic-v1 fixa limite 500000 centavos e rejeita conta inativa. V2 append-only mantém V1.
Outbox usa claim curto SKIP LOCKED, token/lease DB30s, ordem por agregado, publish fora SQL. Consumer confirma offset após commit; retry limitado/jitter, DLT bounded confirmada, pausa/retomada quando indisponível. Recovery opt-in; requeue canônico exige gate/motivo e auditoria. Não há reversal/Mongo/Redis/Keycloak/ACLs/export/dashboard/K8s/cloud.

## Evidência final
work/f2-clean-final5.log e .exit: **BUILD SUCCESS, exit0, 71 testes, zero failures/errors/skips**, reactor 04:09 (não benchmark). Domain13 + policy3 + app4 + arquitetura2 + API31 + Kafka18. Verifica admissão concorrente/last funds, posting concorrente, rollback, dedup, tenant/auth, SQL guards (inclusive NULL reason), upgrade V1 existente, fencing/ordem, retry/DLT/offset, recovery e requeue auditado. Morte real de JVM test-only após claim e expiração natural30s passou; outras janelas pré/pós-commit são modeladas, não kills em todos os pontos.
scripts/validate-contracts.py passou com OpenAPI + accepted/posted/rejected/quarantine reais; identidade/tempo e hash/bytes DLT conferidos. Requeue jar sem gate recusou exit1 antes de credentials. Relatório docs/VALIDATION_F2.md, evidence/f2-validation.json, ADR-002, RUNBOOK_F2 e README. Matriz atualizada por work/update-f2-matrix.py, sem alegar fases futuras/produção.
Runs intermediários: final2 passou70; final3 interrompido após API31; final4 falhou por Docker fechado. Docker29.4.2 restaurado, preflight adicionado; final5 validou código completo. Esses runs não substituem final5.
Pacote F2: outputs/dtp-processamento-f2.zip, criado/verificado por work/package-f2.py, sem target/logs/segredos; V1 comparada byte a byte ao ZIP histórico F1. ZIP F1 preservado. Conferir pacote após este checkpoint, antes de entregar.

## Próximas ações exatas
1. Executar/conferir work/package-f2.py e links locais finais; mostrar README/VALIDATION_F2 e pacote. Não repetir testes sem alteração/falha nova.
2. F3 exige nova aprovação: Activity Mongo/rebuild/grupos independentes e Redis quota, conforme proposta. Pode solicitar autorização explícita F3–F8 locais para continuidade por fases; não inferir do teto de cota. Nenhuma nova implementação enquanto não aprovada.
3. Após resposta, registrar escopo em PROGRESSO/CODEX/AGENTS antes de avançar. Se cota atingir aproximadamente5%, salvar checkpoint e parar. Consultas não são contador contínuo.

## Retomada/ferramentas
Ler PROGRESSO/CODEX; se necessário README/VALIDATION_F2. JDK work/toolchains/jdk21/jdk-21.0.12.1+1; Maven Wrapper3.9.16. Python C:/Users/Gabriel/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe; PYTHONPATH work/validation-packages. Docker disponível; fixtures descartáveis/digests fixos, sem reuse/DB externo. Spring Boot/Kafka4.1.1, clienteKafka4.2.1, broker4.2.0, PG17.6, Testcontainers2.0.5.
Helpers: summarize-f2-validation.py lê final5/XML; update-f2-matrix.py; finish-f2-docs.py; package-f2.py. Atualizar após gate/decisão e antes de encerrar/compactar; reconciliar estado real se interrompido. Não repetir pesquisa/downloads nem alterar Hubs.

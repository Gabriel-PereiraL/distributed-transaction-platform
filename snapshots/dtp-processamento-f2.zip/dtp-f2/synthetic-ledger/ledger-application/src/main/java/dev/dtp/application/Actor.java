package dev.dtp.application;

import java.util.Objects;
import java.util.UUID;

public record Actor(UUID tenantId, String subject, String clientId) {
    public Actor {
        Objects.requireNonNull(tenantId);
        if (subject == null || subject.isBlank() || subject.length() > 128
                || clientId == null || clientId.isBlank() || clientId.length() > 128) {
            throw new IllegalArgumentException("Invalid authenticated identity.");
        }
    }
}
